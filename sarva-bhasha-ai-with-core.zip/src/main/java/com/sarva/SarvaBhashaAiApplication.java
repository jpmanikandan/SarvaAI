
package com.sarva;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SarvaBhashaAiApplication {

    public static void main(String[] args) {
        SpringApplication.run(SarvaBhashaAiApplication.class, args);
    }
}
