
package com.sarva.api;

import com.sarva.core.AgentRouter;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/chat")
public class ChatController {

    private final AgentRouter agentRouter;

    public ChatController(AgentRouter agentRouter) {
        this.agentRouter = agentRouter;
    }

    @PostMapping
    public String chat(@RequestBody String query) {
        return agentRouter.route(query);
    }
}
