
package com.sarva.core;

public interface SarvaAgent {
    String getName();
    boolean canHandle(String query);
    String handle(String query);
}
