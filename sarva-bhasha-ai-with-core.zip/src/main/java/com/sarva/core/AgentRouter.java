
package com.sarva.core;

import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class AgentRouter {

    private final List<SarvaAgent> agents;

    public AgentRouter(List<SarvaAgent> agents) {
        this.agents = agents;
    }

    public String route(String query) {
        return agents.stream()
                .filter(agent -> agent.canHandle(query))
                .findFirst()
                .map(agent -> agent.handle(query))
                .orElse("No suitable agent found for query");
    }
}
