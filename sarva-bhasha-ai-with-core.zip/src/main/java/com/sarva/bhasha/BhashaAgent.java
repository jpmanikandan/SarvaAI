
package com.sarva.bhasha;

import com.sarva.core.SarvaAgent;
import org.springframework.stereotype.Component;

@Component
public class BhashaAgent implements SarvaAgent {

    @Override
    public String getName() {
        return "SarvaBhashaAgent";
    }

    @Override
    public boolean canHandle(String query) {
        return query.toLowerCase().contains("translate")
                || query.toLowerCase().contains("language");
    }

    @Override
    public String handle(String query) {
        return "Bhasha AI response (placeholder) for: " + query;
    }
}
